import importlib.metadata

__version__ = importlib.metadata.version("PID_Py")
__author__ = "ThunderTecke <thunder.tecke@gmail.com>"
__all__=["PID", "Simulation"]